Compiler_Generated_Tests:

These are text files which I ran through the compiler to generate.

Manually_Generated_Tests:

This contains the file which I used to manually write out tests.

Outputs:

The expected output based on the corresponding binary.

Test_Binaries:

The actual binary files to use as test cases.